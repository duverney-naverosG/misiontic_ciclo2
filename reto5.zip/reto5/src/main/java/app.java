import controller.ControladorRequerimientosReto4;
public class app {
    public static void main( String[] args ){

        ControladorRequerimientosReto4 controlador = new ControladorRequerimientosReto4();
        controlador.inicio();
    }
}
